module.exports=[36149,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_event-details_page_actions_07rdiz5.js.map