module.exports=[78256,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_user-profile_page_actions_08272kn.js.map