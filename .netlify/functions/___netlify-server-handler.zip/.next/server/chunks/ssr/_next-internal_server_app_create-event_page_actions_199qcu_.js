module.exports=[64704,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_create-event_page_actions_199qcu_.js.map