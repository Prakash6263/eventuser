module.exports=[94525,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-events_page_actions_1uzh2ow.js.map