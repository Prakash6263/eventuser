globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/0GdR9XZ7iRw-RQMK97dkW/_buildManifest.js",
    "static/0GdR9XZ7iRw-RQMK97dkW/_ssgManifest.js",
    "static/0GdR9XZ7iRw-RQMK97dkW/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3xocbmg7fr2yh.js",
    "static/chunks/1fj6kbkj_syo6.js",
    "static/chunks/1eglloh0s_w8l.js",
    "static/chunks/turbopack-42ptid-dceq11.js"
  ]
};
